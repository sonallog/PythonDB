import pymysql

try:
    modelname=input('Enter Modelname : ')
    con=pymysql.connect(host='bwm0fqxn5mjlvcr1euzw-mysql.services.clever-cloud.com',user='u3baje9bgrwfunkp',password='uBkscIEHmAJHooXt2UYx',database='bwm0fqxn5mjlvcr1euzw')
    curs=con.cursor()
    curs.execute("select * from mobiles where modelname=%s " %modelname)
    data=curs.fetchone()
    print(data)

    if data:
        purpose=input("Enter Purpose : ")
        curs.execute("Update mobiles set purpose=%s where modelname=%s"%(purpose, modelname))
        data=curs.fetchone()
        con.commit()
        print(data)

    else:
        print("data not found")
        con.close()

except Exception as e:
    print(e) 
    