import pymysql

try:
    con=pymysql.connect(host='bwm0fqxn5mjlvcr1euzw-mysql.services.clever-cloud.com',user='u3baje9bgrwfunkp',password='uBkscIEHmAJHooXt2UYx',database='bwm0fqxn5mjlvcr1euzw')
    curs=con.cursor()

    no=int(input('Enter mobile prodid : '))
    curs.execute("select * from mobiles where prodid=%d" %no)
    data=curs.fetchone()
    print(data)
    if data:
        #print(data)
        cho=input('Do you really want to delete? (yes/no) : ')
        if cho=='yes':
            curs.execute("delete from mobiles where prodid=%d" %no)
            con.commit()
            print('mobile data deleted successfully')
        else:
            print('deletion is cancelled')
    else:
        print('mobile not found')
    con.close()
except:
    print('delete transaction failed')