import pymysql

try:

    con=pymysql.connect(host='bwm0fqxn5mjlvcr1euzw-mysql.services.clever-cloud.com',user='u3baje9bgrwfunkp',password='uBkscIEHmAJHooXt2UYx',database='bwm0fqxn5mjlvcr1euzw')
    curs=con.cursor()
    curs.execute("alter table mobiles add purpose varchar(50)")

    data=curs.fetchall()
    print("add new cloumn")

    
except: 
    data=curs.fetchall()
    print("can not add")

con.close()