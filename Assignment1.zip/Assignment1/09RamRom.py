import pymysql

try:
    ram=input('Enter Ram : ')
    rom=input("Enter Rom : ")
    con=pymysql.connect(host='bwm0fqxn5mjlvcr1euzw-mysql.services.clever-cloud.com',user='u3baje9bgrwfunkp',password='uBkscIEHmAJHooXt2UYx',database='bwm0fqxn5mjlvcr1euzw')
    curs=con.cursor()
    curs.execute("select * from Mobiles where ram=%s and rom=%s" %(ram,rom))
    data=curs.fetchall()

    print("List of mobiles having above ram rom storage space combination")


    for rec in data:
      print(rec[2])

except Exception as x:
    print(x)


    