import pymysql

con=pymysql.connect(host='bwm0fqxn5mjlvcr1euzw-mysql.services.clever-cloud.com',user='u3baje9bgrwfunkp',password='uBkscIEHmAJHooXt2UYx',database='bwm0fqxn5mjlvcr1euzw')
print('connected to cloud db...')
curs=con.cursor()
curs.execute("select * from mobiles")
data=curs.fetchall()
print(data)
con.close()
