import pymysql

try:
    prodid=int(input('Enter a mobile id: '))
    modelname=input('Enter a model name: ')
    company=input('Enter a company name: ')
    connectivity=input('Enter a connectivity: ')
    ram=input('Enter a mobile ram: ')
    rom=input('Enter a mobile rom: ')
    color=input('Enter a mobile color: ')
    screen=input('Enter a screen type: ')
    battery=input('Enter a battery backup: ')
    processor=input('Enter a type of processor: ')
    price=input('Enter a price: ')
    rating=float(input('Enter a rating: '))

    con=pymysql.connect(host='bwm0fqxn5mjlvcr1euzw-mysql.services.clever-cloud.com',user='u3baje9bgrwfunkp',password='uBkscIEHmAJHooXt2UYx',database='bwm0fqxn5mjlvcr1euzw')
    curs=con.cursor()
    curs.execute("insert into mobiles values(%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s',%2f)" %(prodid,modelname,company,connectivity,ram,rom,color,screen,battery,processor,price,rating))
    con.commit()
    con.close()
    print("new mobile data added to database successfully")

except:
    print("mobile data can not added")    

