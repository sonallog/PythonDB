import pymysql

try:
    con=pymysql.connect(host='bwm0fqxn5mjlvcr1euzw-mysql.services.clever-cloud.com',user='u3baje9bgrwfunkp',password='uBkscIEHmAJHooXt2UYx',database='bwm0fqxn5mjlvcr1euzw')
    curs=con.cursor()
    id=int(input('Enter prodid : '))
    curs.execute("select * from mobiles where prodid=%d" %id)
    data=curs.fetchone()
    print(data)
    if data:
        price=float(input('Enter new price  : '))
        curs.execute("update mobiles set price=%d where prodid=%d" %(price,id))
        con.commit()
        print('Mobile price updated')
    else:
        print('Mobile not found')
    con.close()
    
except:
       print('updatation failed')
       
