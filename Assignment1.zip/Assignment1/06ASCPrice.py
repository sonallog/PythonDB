import pymysql

comp=input("Enter a company : ")
con=pymysql.connect(host='bwm0fqxn5mjlvcr1euzw-mysql.services.clever-cloud.com',user='u3baje9bgrwfunkp',password='uBkscIEHmAJHooXt2UYx',database='bwm0fqxn5mjlvcr1euzw')
curs=con.cursor()
curs.execute("select * from mobiles where company=%s order by price asc"%comp)

data=curs.fetchall()
print(data)

con.close()