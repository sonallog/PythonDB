import pymysql

try:
    modelnm=input("Enter modelname: ")  
    con=pymysql.connect(host='bwm0fqxn5mjlvcr1euzw-mysql.services.clever-cloud.com',user='u3baje9bgrwfunkp',password='uBkscIEHmAJHooXt2UYx',database='bwm0fqxn5mjlvcr1euzw')
    curs=con.cursor()
    curs.execute("select * from mobiles where modelname=%s" %modelnm)

    data=curs.fetchone()
    print(data)
    

    
except Exception as x:
    
    print("Data not found")
    print(x) 

  